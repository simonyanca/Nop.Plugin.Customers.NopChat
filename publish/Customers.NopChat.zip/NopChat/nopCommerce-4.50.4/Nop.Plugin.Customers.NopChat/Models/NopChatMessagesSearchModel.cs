﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Customers.NopChat.Models
{
    public record NopChatMessagesSearchModel : BaseSearchModel
    {
    }
}
