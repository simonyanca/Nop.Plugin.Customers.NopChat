1. 'Nop.Plugin.Customers.NopChat' directory contains source code.
2. 'Customers.NopChat' contains binaries. Just drop it into \Plugins directory on your server.